"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.baseRoute = void 0;
var baseRoute = exports.baseRoute = process.env.BASE_ROUTE || '';